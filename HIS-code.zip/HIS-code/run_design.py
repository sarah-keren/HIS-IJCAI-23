
"kofi"
import argparse
import logging
import os
import re
import time

from UMD import constraint, design, search

import defs_apk
import er_poa_kp
import er_umd
import heuristic_apk
import his
import kac
import his_rob
import pruning_apk
import utils_apk
from solver_kp import solve


def process_input(args: argparse.Namespace):
    utility = 'his'
    defs_apk.set_utility(utility)
    domain_file_name = args.domain_path
    domain_id = utils_apk.get_domain_id(domain_file_name)
    defs_apk.set_domain_ID(domain_id)
    template_file_name = args.template_path
    hyps_file_name = args.hyps_path
    instance_id = utils_apk.get_instance_id(domain_file_name, hyps_file_name)
    design_file_name = args.design_path
    design_problem_file_name = args.design_problem_path
    design_budget = args.budget
    search_method_name = args.method
    defs_apk.set_search_method_name(search_method_name)
    heuristic_name = args.heuristic
    pruning_methods_name = args.pruning
    solver_path = args.solver_path
    solver_type = defs_apk.get_solver_type(solver_path)
    planner_type = args.planner.lower()
    defs_apk.set_planner_type(planner_type)
    compilation = args.compilation
    defs_apk.set_compilation(compilation)
    objective = args.objective
    if objective is not None:
        objective = objective.lower()
    defs_apk.set_objective(objective)
    defs_apk.set_robustness(args.robustness)

    log_file, log_file_results, log_file_analytics = defs_apk.create_log_files(args.logs)
    utils_apk.initialize_logging(log_file_analytics.name)

    um_problems = list()

    with open(hyps_file_name, "r") as original_hyps_file:
        lines = original_hyps_file.readlines()
    for index, hyp in enumerate(lines):
        parsed_hyps_file_name = os.path.abspath(os.path.join(
            defs_apk.get_gen_folder_name(args.logs), 'parsed_hyps_%d.dat' % index))  # todo save the value to variable
        with open(parsed_hyps_file_name, "w") as parsed_hyps_file:
            parsed_hyps_file.write(hyp)
        um_problem = er_poa_kp.ER_POA_KP(
            solver_path, domain_file_name, template_file_name, parsed_hyps_file_name, planner_type, compilation)
        um_problems.append(um_problem)

    # handle constraints
    constraint_list = []
    bud_constraint = constraint.BudgetConstraint(design_budget)
    constraint_list.append(bud_constraint)
    umd_problems = []

    use_simpled_val = 'lazy' in search_method_name
    for um_problem in um_problems:
        umd_problem = his.HIS(um_problem, constraint_list, design_file_name,
                              design_problem_file_name, True, use_simpled_val)
        umd_problems.append(umd_problem)

    umd_problems_and_structs = []
    for umd_problem in umd_problems:
        termination_criteria = None
        termination_criteria = er_umd.TerminationCriteriaReachalbeGoals(
            0, True)

        # create & initialize frontier
        heuristic_func = None
        if defs_apk.NA not in heuristic_name:
            heuristic_func = heuristic_apk.get_heuristic(
                heuristic_name, umd_problem)
            frontier = search.PriorityQueue(min, heuristic_func)
        else:
            frontier = search.FIFOQueue()

        if defs_apk.NA in pruning_methods_name:
            prune_func = None  # pruning.prune_grd_currentFocus
        else:
            prune_func = pruning_apk.get_pruning_func(
                pruning_methods_name, umd_problem)
        umd_problems_and_structs.append([utility, umd_problem, search_method_name, compilation,
                                         frontier, termination_criteria, heuristic_name, prune_func, log_file, log_file_results])

    return umd_problems_and_structs


def run_design(umd_problem, search_method_name, compilation, frontier, termination_criteria,  heuristic_name, prune_func, log_file, log_file_results, robustness=None):

    logging.info('Running instance_id:%s, utility:%s, design_budget:%s, search_method_name:%s, heuristic:%s, pruning_methods_name:%s, solver_path:%s, compilation:%s, planner_type:%s' % (
        utils_apk.get_instance_id(umd_problem.initial_model.domain_file_name, umd_problem.initial_model.hyps_file_name), umd_problem.utility, umd_problem.constraints[0], search_method_name, heuristic_name, prune_func,  umd_problem.initial_model.solver_path, umd_problem.initial_model.compilation, umd_problem.initial_model.planner_type))

    log_file.write('\nDesigning domain::%s\ntemplate::%s\nhyps::%s\nbudget::%s\nmethod::%s\nheuristic::%s\npruning::%s\nsolver::%s\nplanner::%s\ncompilation::%s\n' %
                   (umd_problem.initial_model.domain_file_name, umd_problem.initial_model.template_file_name, umd_problem.initial_model.hyps_file_name, umd_problem.constraints, search_method_name, heuristic_name, prune_func, umd_problem.initial_model.solver_path, umd_problem.initial_model.planner_type, umd_problem.initial_model.compilation))
    log_file.write('\n----------------------\n')
    log_file.flush()

    log_file_results.write('\n----------------------')
    log_file_results.write('\nDesigning domain::%s\ntemplate::%s\nhyps::%s\nbudget::%s\nmethod::%s\nheuristic::%s\npruning::%s\nsolver::%s\nplanner::%s\ncompilation::%s\nobjective::%s\n' %
                           (umd_problem.initial_model.domain_file_name, umd_problem.initial_model.template_file_name, umd_problem.initial_model.hyps_file_name, umd_problem.constraints, search_method_name, heuristic_name, prune_func, umd_problem.initial_model.solver_path, umd_problem.initial_model.planner_type, umd_problem.initial_model.compilation, defs_apk.OBJECTIVE))
    log_file_results.flush()

    if defs_apk.BFD.lower() in search_method_name.lower():
        closed_list = search.ClosedListOfSets()

        # time
        start_time = time.time()

        # perform design
        # Lazy BFD with simplified values
        search_node_for_evaluation = 'lazy' in search_method_name.lower()
        best_value, best_node, explored, ex_terminated, results_log = design.best_first_design(
            umd_problem, frontier, closed_list, termination_criteria, prune_func, log_file, log_file_results, defs_apk.ITER_LIMIT, defs_apk.DEFAULT_TIME_LIMIT, use_search_node_for_evaluation=search_node_for_evaluation)

        # get exe time
        calc_time = time.time() - start_time  # , "seconds"

        # log results
        for cost in results_log:
            log_message = 'Best_value_for_cost-%d:' % cost+defs_apk.SEPARATOR + 'cur_value::%d' % results_log[cost][0] + defs_apk.SEPARATOR + 'cur_node::' + str(
                results_log[cost][1]) + defs_apk.SEPARATOR + 'calc_time::%.2f' % results_log[cost][2] + defs_apk.SEPARATOR + 'explored::%d' % results_log[cost][3]+'\n'
            log_file_results.write(log_message)

        log_message = 'Total_best_value:%.2f' % best_value + defs_apk.SEPARATOR + ' best_node:' + str(best_node) + defs_apk.SEPARATOR + 'cost:%.2f' % best_node.cost(
        )[0] + defs_apk.SEPARATOR + 'explored:%s' % explored + defs_apk.SEPARATOR + 'time:%.6f' % calc_time + defs_apk.SEPARATOR + 'ex_terminated:' + str(ex_terminated) + '\n'
        log_file.write(log_message)
        log_file_results.write(log_message)
    elif 'kp' in compilation:
        domain_path = umd_problem.initial_model.domain_file_name
        compiler_path = umd_problem.initial_model.solver_path
        planner_type = umd_problem.initial_model.planner_type
        problem_files = umd_problem.initial_model.get_problem_files()
        for index, problem_path in enumerate(problem_files):
            start_time = time.time()
            if robustness is None:
                _, has_solution_po, po_plan_cost, _, _, _, _, _, _ = solve(compiler_path, domain_path, problem_path, planner_type,
                                                                        index, compilation, True, False, False)
            else:
                has_solution_po, _, _, _, po_plan_cost = his_rob.solver_his_rob(
                compiler_path, domain_path, problem_path, None, None, index, None, planner_type, robustness, defs_apk.OBJECTIVE, False)
            if has_solution_po:
                value = 0
                cost = 0
            else:
                value = defs_apk.INFINITE
                cost = defs_apk.INFINITE
            calc_time = time.time() - start_time
            if robustness is not None:
                log_file_results.write(f'robustness::{robustness}\n')
            log_message = 'Total_best_value:%.2f' % value + defs_apk.SEPARATOR + ' best_node:<Node[]>' + defs_apk.SEPARATOR + 'cost:%.2f' % cost + defs_apk.SEPARATOR + \
                'plan cost:%.2f' % po_plan_cost + defs_apk.SEPARATOR + 'explored:1' + defs_apk.SEPARATOR + \
                'time:%.6f' % calc_time + defs_apk.SEPARATOR + 'ex_terminated:False\n'
            log_file_results.write(log_message)
    elif 'kat' in compilation:
        domain_path = umd_problem.initial_model.domain_file_name
        compiler_path = umd_problem.initial_model.solver_path
        planner_type = umd_problem.initial_model.planner_type
        problem_files = umd_problem.initial_model.get_problem_files()
        design_domain_path = umd_problem.design_file_name
        design_problem_path = umd_problem.design_problem_name
        hidden_facts = umd_problem.initial_model.rec_knowledge

        is_negative_pattern = re.compile('\s*\(\s*not\s*\(.+')
        fluent_content_pattern = re.compile('\(\s*([\w\s\-]+)\s*\)')
        for index, problem_path in enumerate(problem_files):
            start_time = time.time()
            has_solution, plan, acquired_knowledge, cost, _ = kac.solve_kac(
                compiler_path, domain_path, problem_path, design_domain_path, design_problem_path, index, hidden_facts, planner_type, defs_apk.OBJECTIVE)
            transition_path = list()
            if has_solution:
                value = 0
                cost = len(acquired_knowledge)
                plan_cost = len(plan)
                for fluent in acquired_knowledge:
                    fluent_content = next(re.finditer(
                        fluent_content_pattern, fluent)).group(1)
                    modification_name = ''
                    if re.match(is_negative_pattern, fluent) is not None:
                        modification_name += '_not_'
                    index = fluent_content.find(' ')
                    modification_name += fluent_content[:index] + \
                        '=' + fluent_content[index + 1:].replace(' ', '=')
                    transition_path.append(modification_name)
            else:
                value = defs_apk.INFINITE
                cost = defs_apk.INFINITE
                plan_cost = defs_apk.INFINITE
            node = "<Node{}>".format(transition_path)
            calc_time = time.time() - start_time
            log_message = 'Total_best_value:%.2f' % value + defs_apk.SEPARATOR + ' best_node:' + node + defs_apk.SEPARATOR + 'cost:%.2f' % cost + defs_apk.SEPARATOR + \
                'plan cost:%.2f' % plan_cost + defs_apk.SEPARATOR + 'explored:1' + defs_apk.SEPARATOR + \
                'time:%.6f' % calc_time + defs_apk.SEPARATOR + 'ex_terminated:False\n'
            log_file_results.write(log_message)
    elif 'his-rob' in compilation:
        domain_path = umd_problem.initial_model.domain_file_name
        compiler_path = umd_problem.initial_model.solver_path
        planner_type = umd_problem.initial_model.planner_type
        problem_files = umd_problem.initial_model.get_problem_files()
        design_domain_path = umd_problem.design_file_name
        design_problem_path = umd_problem.design_problem_name
        hidden_facts = umd_problem.initial_model.rec_knowledge
        # robustness = 0.125

        is_negative_pattern = re.compile('\s*\(\s*not\s*\(.+')
        fluent_content_pattern = re.compile('\(\s*([\w\s\-]+)\s*\)')
        for index, problem_path in enumerate(problem_files):
            start_time = time.time()
            has_solution, _, acquired_knowledge, cost, plan_cost = his_rob.solver_his_rob(
                compiler_path, domain_path, problem_path, design_domain_path, design_problem_path, index, hidden_facts, planner_type, robustness, defs_apk.OBJECTIVE)
            transition_path = list()
            if has_solution:
                value = 0
                cost = len(acquired_knowledge)
                for fluent in acquired_knowledge:
                    fluent_content = next(re.finditer(
                        fluent_content_pattern, fluent)).group(1)
                    modification_name = ''
                    if re.match(is_negative_pattern, fluent) is not None:
                        modification_name += '_not_'
                    i = fluent_content.find(' ')
                    modification_name += fluent_content[: i] + '=' + fluent_content[i + 1:].replace(' ', '=')
                    transition_path.append(modification_name)
            else:
                value = defs_apk.INFINITE
                cost = defs_apk.INFINITE
            node = "<Node{}>".format(transition_path)
            calc_time = time.time() - start_time
            log_file_results.write(f'robustness::{robustness}\n')
            log_message = 'Total_best_value:%.2f' % value + defs_apk.SEPARATOR + ' best_node:' + node + defs_apk.SEPARATOR + 'cost:%.2f' % cost + defs_apk.SEPARATOR + \
                'plan cost:%.2f' % plan_cost + defs_apk.SEPARATOR + 'explored:1' + defs_apk.SEPARATOR + \
                'time:%.6f' % calc_time + defs_apk.SEPARATOR + 'ex_terminated:False\n'
            log_file_results.write(log_message)

    else:
        print('only BFD search method supported for now: existing')
        raise NotImplementedError("unrecognized method")

    folder_path = defs_apk.get_gen_folder_name()
    # from IPython import embed
    # embed()
    for name in os.listdir(folder_path):
        if name.startswith('template_') or name.startswith('gen-'):
            path = os.path.join(folder_path, name)
            os.remove(path)
    # embed()
    return


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('domain_path', type=str, help='Path to domain file')
    parser.add_argument('template_path', type=str,
                        help='Path to template file')
    parser.add_argument('hyps_path', type=str, help='Path to hyps file')
    parser.add_argument('design_path', type=str, help='Path to design file')
    parser.add_argument('design_problem_path', type=str,
                        help='Path to design problem file')
    parser.add_argument('budget', type=int,
                        help='The budget of information shaping modifications')
    parser.add_argument('method', type=str, help='The search method to use')
    parser.add_argument('heuristic', type=str, help='The heuristic to use')
    parser.add_argument('pruning', type=str, help='The pruning method to use')
    parser.add_argument('compilation', type=str, help='The compilation to use')
    parser.add_argument('solver_path', type=str, help='Path to the solver')
    parser.add_argument('planner', type=str, help='The type of planner to use')
    parser.add_argument('--objective', type=str, default='NA',
                        help='The objective of the actor')
    parser.add_argument('--robustness', type=float, default=None)
    parser.add_argument('--logs', default='logs', help='Path to logs folder')
    args = parser.parse_args()
    umd_problems = process_input(args)

    # input('Waiting before running. ')
    
    print('len(umd_problems) =', len(umd_problems))
    for umd_problem in umd_problems:
        utility, umd_problem, search_method_name, compilation, frontier, termination_criteria, heuristic_name, prune_func, log_file, log_file_results = umd_problem
        run_design(umd_problem, search_method_name, compilation, frontier,
                   termination_criteria, heuristic_name, prune_func, log_file, log_file_results, args.robustness)
    log_file.close()
    log_file_results.close()

    # if args.robustness == 0.125 and 'RockSample/Set-4/p08' in args.domain_path:
    # input('Waiting after running. ')
