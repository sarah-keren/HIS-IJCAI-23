__author__ = 'David Wies'

import os
import re

import defs_apk
import pddl_parser
import solver_kp
from typing import List

comment_pattern = re.compile(';[^\\n]*')
def read_pddl_file(path: str):
    with open(path) as file:
        file_content = file.read()
    return comment_pattern.sub('', file_content)
    

sensor_pattern = re.compile('\(:sensor\s+([\w\-]+)\s+:parameters\s*(\([\w\?\s\-]+\))\s*:condition\s*\((and\s*(\([\w\?\-\s]+\)\s*)+|[\w\?\-\s]+)\)\s*:sense\s*(\([\w\?\s\-]+\))\s*\)')
def get_sensors(domain_code: str):
    global sensor_pattern
    sensors = list()
    for sensor_match in sensor_pattern.finditer(domain_code):
        name = sensor_match.group(1)
        parameters = sensor_match.group(2)
        conditions = '(' + sensor_match.group(3) + ')'
        sense = sensor_match.group(5)
        sensors.append([name, parameters, conditions, sense])
    return sensors

action_pattern = re.compile('\(:action\s+([\w\-]+)\s+(:parameters\s*(\(.*\)))?\s*(:precondition\s*(\(.*\)))?\s*:effect\s*(\(.+\))\s*\)')
def get_actions(domain_code: str):
    global action_pattern
    actions = list()
    for action_match in action_pattern.finditer(domain_code):
        name = action_match.group(1)
        parameters = action_match.group(3)
        precondition = action_match.group(5)
        effect = action_match.group(6)
        actions.append([name, parameters, precondition, effect])
    return actions

predicates_section_pattern = re.compile('\(:predicates\s+(\([\w\s\?\-]+\)\s*)+\s*\)')
predicate_pattern = re.compile('\([\w\s\?\-]+\)')
def get_predicates(domain_code: str):
    global predicates_section_pattern
    match = next(predicates_section_pattern.finditer(domain_code))
    start, end = match.span()
    predicates_section = domain_code[start: end]
    global predicate_pattern
    return predicate_pattern.findall(predicates_section)


domain_name_pattern = re.compile('\(define\s*\(domain\s+([\w\-]+)')
def get_name(domain_code: str):
    global domain_name_pattern
    return domain_name_pattern.findall(domain_code)[0].strip()

requirements_pattern = re.compile('\(:requirements\s+((:[\w\-]+\s*)+)\)')
def get_requirements(domain_code: str):
    global requirements_pattern
    requirements_list = requirements_pattern.findall(domain_code)[0]
    return ' '.join(requirements_list)


types_pattern = re.compile('\(:types\s+([\w\s\-]+)\)')
def get_types(domain_code: str):
    global types_pattern
    return types_pattern.findall(domain_code)[0].strip()


constants_pattern = re.compile('\(:constants\s[^\)]+\)')
def get_constants(domain_code: str):
    global constants_pattern
    constants = constants_pattern.findall(domain_code)
    return '' if len(constants) == 0 else constants[0]


def parse_domain(domain_path: str):
    domain_code = read_pddl_file(domain_path)
    predicates = get_predicates(domain_code)
    actions = get_actions(domain_code)
    sensors = get_sensors(domain_code)
    name = get_name(domain_code)
    constants = get_constants(domain_code)
    requirements = get_requirements(domain_code)
    types = get_types(domain_code)
    return name, requirements, types, constants, predicates, actions, sensors


def fluent_to_hidden_fluent(fluent: str):
    fluent = fluent.strip()
    return '(hidden_' + fluent[1:]


def fluent_to_kac_fluent(fluent: str, positive:bool=True):
    fluent = fluent.strip()
    prefix = '(kac_' if positive else '(kac_not_'
    fluent = prefix + fluent[1:]
    return fluent


def sensor_to_kac_sensors(sensor: List[str]):
    name_true = sensor[0] + '-true'
    name_false = sensor[0] + '-false'
    parameters = sensor[1]
    hidden_fluent = fluent_to_hidden_fluent(sensor[-1])
    condition = sensor[2]
    if condition.startswith('(and'):
        precondition_true = f'(and (not (design)) {hidden_fluent} {condition[5:]}'
        precondition_false = f'(and (not (design)) (not {hidden_fluent}) {condition[5:]}'
    else:
        precondition_true = f'(and (not (design)) {hidden_fluent} {sensor[2]})'
        precondition_false = f'(and (not (design)) (not {hidden_fluent}) {sensor[2]})'
    effect_true = sensor[-1]
    effect_false = f'(not {sensor[-1]})'
    kac_sensor_true = f'(:action sensor-{name_true}\n\t:parameters {parameters}\n\t:precondition {precondition_true}\n\t:effect {effect_true}\n)\n'
    kac_sensor_false = f'(:action sensor-{name_false}\n\t:parameters {parameters}\n\t:precondition {precondition_false}\n\t:effect {effect_false}\n)\n'
    return kac_sensor_true, kac_sensor_false


def action_to_kac_action(action: List[str]):
    new_action = f'(:action {action[0]}\n'
    parameters = action[1]
    if parameters is not None:
        new_action += f'\t:parameters {parameters}\n'
    precondition = action[2]
    if precondition is not None and precondition.startswith('(and'):
        precondition = '(and (not (design)) ' + precondition[5:]
    else:
        precondition = f'(and (not (design)) {action[2]})'
    new_action += f'\t:precondition {precondition}\n\t:effect {action[3]}\n)\n'
    return new_action


def create_information_shaping_action(predicate: str):
    predicate_without_types = re.sub('\s+\-\s+[^\s\)]+', '', predicate)
    parts = predicate[1: -1].split()
    name = parts[0]
    parameters = ' '.join(parts[1:])
    name_true = 'information-shaping-true-' + name
    name_false = 'information-shaping-false-' + name
    precondition_true = f'(and (design) {fluent_to_kac_fluent(predicate_without_types)})'
    precondition_false = f'(and (design) {fluent_to_kac_fluent(predicate_without_types, False)})'
    effect_true = predicate_without_types
    effect_false = f'(not {effect_true})'
    action_true = f'(:action {name_true}\n\t\t:parameters ({parameters})\n\t\t:precondition {precondition_true}\n\t\t:effect {effect_true}\n\t)\n'
    action_false = f'(:action {name_false}\n\t\t:parameters ({parameters})\n\t\t:precondition {precondition_false}\n\t\t:effect {effect_false}\n\t)\n'
    return action_true, action_false


def get_helper_knowledge(design_domain_path: str, design_problem_path: str, hidden_facts: List[str]):
    _, _, planning_task = pddl_parser.parse_pddl_files(design_domain_path, design_problem_path)
    facts_tmp = planning_task.facts - planning_task.goals
    helper_knowledge = list()
    for fact in facts_tmp:
        if fact[1: -1] in hidden_facts:
            helper_knowledge.append(fact)
        else:
            helper_knowledge.append(f'(not {fact})')
    return helper_knowledge


def path_to_kac_path(path: str):
    name = os.path.basename(path)
    name, extension = os.path.splitext(name)
    kac_name = name + '-kac' + extension
    kac_path = os.path.join(defs_apk.get_gen_folder_name(), kac_name)
    return kac_path


def predicate_to_kac_predicates(predicate: str):
    predicate_true = fluent_to_kac_fluent(predicate)
    predicate_false = fluent_to_kac_fluent(predicate, positive=False)
    hidden_predicate = fluent_to_hidden_fluent(predicate)
    predicates = f'{predicate} {predicate_true} {predicate_false} {hidden_predicate}'
    return predicates


def write_kac_domain(domain_path: str):
    name, requirements, types, constants, predicates, original_actions, sensors = parse_domain(domain_path)
    kac_domain_path = path_to_kac_path(domain_path)
    with open(kac_domain_path, 'w+') as kac_domain_file:
        information_shaping_actions = list()
        kac_domain_file.write(f'(define (domain {name})\n\n\t(:requirements {requirements})\n\n\t(:types\n\t\t{types}\n\t)\n\n{constants}\n\n\t(:predicates\n')
        for predicate in predicates:
            kac_predicates = predicate_to_kac_predicates(predicate)
            kac_domain_file.write(f'\t\t{kac_predicates}\n')
            action_1, action_2 = create_information_shaping_action(predicate)
            information_shaping_actions.append('\t' + action_1)
            information_shaping_actions.append('\t' + action_2)
        kac_domain_file.write('\t\t(design)\n\t)\n\n')
        for action in information_shaping_actions:
            kac_domain_file.write(action + '\n')
        kac_domain_file.write('\n\t(:action switch_from_design\n\t\t:precondition (design)\n\t\t:effect (not (design))\n\t)\n\n')
        for action in original_actions:
            new_action = action_to_kac_action(action)
            kac_domain_file.write('\n\t' + new_action.replace('\n', '\n\t'))
        kac_domain_file.write('\n')
        for sensor in sensors:
            sensor_1, sensor_2 = sensor_to_kac_sensors(sensor)
            kac_domain_file.write('\n\t' + sensor_1.replace('\n', '\n\t'))
            kac_domain_file.write('\n\t' + sensor_2.replace('\n', '\n\t'))
        kac_domain_file.write('\n)')
    return kac_domain_path


negative_pattern = re.compile('\(\s*not\s*(\([\w\s\-]+\))\)')
def fluent_to_acquisition_fluent(design_fluent: str):
    global negative_pattern
    design_fluent = design_fluent.strip()
    match = negative_pattern.match(design_fluent)
    is_negative = False
    if match:
        is_negative = True
        design_fluent = match.group(1)
    prefix = '(kac_not_' if is_negative else '(kac_'
    fluent = prefix + design_fluent[1:]
    return fluent


def write_kac_problem(problem_path, helper_knowledge, hidden_facts):
    kac_problem_path = path_to_kac_path(problem_path)
    with open(kac_problem_path, 'w+') as kac_problem_file, open(problem_path) as problem_file:
        for line in problem_file:
            index = line.find(';')
            if index != -1:
                line = line[:index] + '\n'
            if line.strip() == '':
                continue
            index = line.find('(:init')
            if index == -1:
                kac_problem_file.write(line)
            else:
                index += 6
                kac_problem_file.write(line[:index] + '\n')
                kac_line = '\t\t(design) '
                for fluent in helper_knowledge:
                    kac_line += fluent_to_acquisition_fluent(fluent) + ' '
                kac_problem_file.write(kac_line + '\n\t' + line[index:])
                hidden_knowledge_line = '\n\t\t' + ' '.join(hidden_facts) + '\n\n'
                kac_problem_file.write(hidden_knowledge_line)
                break
        for line in problem_file:
            index = line.find(';')
            if index != -1:
                line = line[:index] + '\n'
            if line.strip() == '':
                continue
            kac_problem_file.write(line)
    return kac_problem_path


def convert_hidden_facts(hidden_facts):
    kac_hidden_fact = list()
    for fact in hidden_facts:
        fact = fact.strip()
        hidden_fact = '(hidden_' + fact + ')'
        kac_hidden_fact.append(hidden_fact)
    return kac_hidden_fact


def convert_to_kac_files(domain_path, problem_path, helper_knowledge, hidden_facts):
    hidden_facts = convert_hidden_facts(hidden_facts)
    kac_domain_path = write_kac_domain(domain_path)
    kac_problem_path = write_kac_problem(problem_path, helper_knowledge, hidden_facts)
    return kac_domain_path, kac_problem_path


is_negative_pattern = re.compile('\s*\(\s*not\s*\(.+')
fluent_content_pattern = re.compile('\(\s*([\w\s\-]+)\s*\)')
def kac_to_fluents(acquired_knowledge, helper_knowledge):
    kac_helper_knowledge = list()
    original_fluents = list()
    global is_negative_pattern
    global fluent_content_pattern
    for fluent in helper_knowledge:
        is_negative = not is_negative_pattern.match(fluent) is None
        fluent_content = next(fluent_content_pattern.finditer(fluent)).group(1)
        kac_fluent = 'not-' if is_negative else ''
        kac_fluent += fluent_content.replace(' ', '_')
        kac_helper_knowledge.append(kac_fluent)
    for fluent in acquired_knowledge:
        original_fluent = helper_knowledge[kac_helper_knowledge.index(fluent)]
        original_fluents.append(original_fluent)
    return original_fluents


start_sensor_pattern = re.compile('\(\s*:sensor\s+')
def domain_to_fo(domain_path):
    domain = read_pddl_file(domain_path)
    domain_fo = ''
    start_index = 0
    for match in start_sensor_pattern.finditer(domain):
        start, end = match.span()
        domain_fo += domain[start_index: start]
        sensor = domain[start: end]
        while sensor.count('(') != sensor.count(')'):
            end = domain.find(')', end + 1)
            sensor = domain[start: end]
        start_index = end + 1
    domain_fo += domain[start_index:]
    name = os.path.basename(domain_path)
    name, extension = os.path.splitext(name)
    fo_name = name + '-fo.pddl' + extension
    fo_path = os.path.join(defs_apk.get_gen_folder_name(), fo_name)
    with open(fo_path, 'w+') as fomain_fo_file:
        fomain_fo_file.write(domain_fo)
    return fo_path


start_invariant_pattern = re.compile('\(\s*invariant[\s\(]+')
start_init_pattern = re.compile('\(\s*:init\s+')
start_hidden_pattern = re.compile('\(\s*:hidden\s+')
def problem_to_fo(problem_path):
    problem = read_pddl_file(problem_path)
    hidden_start, hidden_end = next(start_hidden_pattern.finditer(problem))
    problem_fo = ''
    start_index = 0
    for match in start_invariant_pattern.finditer(problem, endpos=hidden_start):
        start, end = match.span()
        problem_fo += problem[start_index: start]
        invariant = problem[start: end]
        while invariant.count('(') != invariant.count(')'):
            end = problem.find(')', end + 1)
            invariant = problem[start: end]
        start_index = end + 1
    end_init = problem.rfind(')', start_index, hidden_start)
    problem_fo += problem[start_index: end_init]
    problem_fo += problem_fo[hidden_end:]
    name = os.path.basename(problem_path)
    name, extension = os.path.splitext(name)
    fo_name = name + '-fo.pddl' + extension
    fo_path = os.path.join(defs_apk.get_gen_folder_name(), fo_name)
    with open(fo_path, 'w+') as problem_fo_file:
        problem_fo_file.write(problem_fo)
    return fo_path


def solve_kac(solver_path, domain_path, problem_path, design_domain_path, design_problem_path, hyp_index, hidden_facts, planner_type, objective):
    helper_knowledge = get_helper_knowledge(design_domain_path, design_problem_path, hidden_facts)
    kac_domain_path, kac_problem_path = convert_to_kac_files(domain_path, problem_path, helper_knowledge, hidden_facts)
    po_plan, has_solution, _, _, _, _, _, _, _ = solver_kp.solve(solver_path, kac_domain_path, kac_problem_path, planner_type, hyp_index, defs_apk.COMPILATION_TYPE, True, False, False, objective=objective)
    cost = 0 if has_solution else defs_apk.INFINITE
    plan = list()
    acquired_knowledge = list()
    if has_solution:
        plan_index = 0
        plan_length = len(po_plan)
        while plan_index < plan_length:
            step = po_plan[plan_index]
            plan_index += 1
            if step == 'switch_from_design':
                break
            knowledge = step[20:]
            if knowledge.startswith('true-'):
                knowledge = knowledge[5:]
            else:
                knowledge = 'not-' + knowledge[6:]
            acquired_knowledge.append(knowledge)
        while plan_index < plan_length:
            step = po_plan[plan_index]
            if not step.startswith('sensor-'):
                plan.append(step)
            plan_index += 1
        acquired_knowledge = kac_to_fluents(acquired_knowledge, helper_knowledge)
    return has_solution, plan, acquired_knowledge, cost, len(plan)
