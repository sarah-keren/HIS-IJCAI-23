__author__ = 'David Wies'


import logging
import os
import time
from typing import List, Tuple

import defs_apk
import utils_apk
from kac import (action_to_kac_action, create_information_shaping_action,
                 fluent_to_acquisition_fluent, fluent_to_kac_fluent,
                 get_helper_knowledge, kac_to_fluents, parse_domain)
from solver_kp import parse_assumptions, parse_beliefs, read_optimistic_plans
import warnings
from IPython import embed
import traceback


def path_to_kminrob_path(path: str) -> str:
    name = os.path.basename(path)
    name, extension = os.path.splitext(name)
    kminrob_name = name + '-kminrob' + extension
    kminrob_path = os.path.join(defs_apk.get_gen_folder_name(), kminrob_name)
    return kminrob_path


def predicate_to_kminrob_predicates(predicate: str) -> str:
    predicate_true = fluent_to_kac_fluent(predicate, positive=True)
    predicate_false = fluent_to_kac_fluent(predicate, positive=False)
    predicates = f'{predicate} {predicate_true} {predicate_false}'
    return predicates


def sensor_to_kminrob_sensor(sensor: List[str]) -> str:
    new_sensor = f'(:sensor {sensor[0]}\n'
    parameters = sensor[1]
    if parameters is not None:
        new_sensor += f'\t:parameters {parameters}\n'
    condition = sensor[2]
    if condition is not None and condition.startswith('(and'):
        condition = '(and (not (design)) ' + condition[5:]
    else:
        condition = f'(and (not (design)) {sensor[2]})'
    new_sensor += f'\t:condition {condition}\n\t:sense {sensor[3]}\n)\n'
    return new_sensor


def write_kminrob_domain(domain_path: str) -> str:
    name, requirements, types, constants, predicates, original_actions, sensors = parse_domain(
        domain_path)
    kminrob_domain_path = path_to_kminrob_path(domain_path)
    information_shaping_actions = list()
    with open(kminrob_domain_path, 'w+') as kminrob_domain_file:
        information_shaping_actions = list()
        kminrob_domain_file.write(
            f'(define (domain {name})\n\n\t(:requirements {requirements})\n\n\t(:types\n\t\t{types}\n\t)\n\n{constants}\n\n\t(:predicates\n')
        for predicate in predicates:
            kminrob_predicates = predicate_to_kminrob_predicates(predicate)
            kminrob_domain_file.write(f'\t\t{kminrob_predicates}\n')
            information_shaping_true, information_shaping_false = create_information_shaping_action(
                predicate)
            information_shaping_actions.append('\t' + information_shaping_true)
            information_shaping_actions.append(
                '\t' + information_shaping_false)
        kminrob_domain_file.write('\t\t(design)\n\t)\n\n')
        for action in information_shaping_actions:
            kminrob_domain_file.write(action + '\n')
        kminrob_domain_file.write(
            '\n\t(:action switch_from_design\n\t\t:precondition (design)\n\t\t:effect (not (design))\n\t)\n\n')
        for action in original_actions:
            new_action = action_to_kac_action(action)
            kminrob_domain_file.write(
                '\n\t' + new_action.replace('\n', '\n\t'))
        kminrob_domain_file.write('\n')
        for sensor in sensors:
            new_sensor = sensor_to_kminrob_sensor(sensor)
            kminrob_domain_file.write(
                '\n\t' + new_sensor.replace('\n', '\n\t'))
        kminrob_domain_file.write('\n)')
    return kminrob_domain_path


def write_kminrob_problem(problem_path: str, helper_knowledge: str) -> str:
    kminrob_problem_path = path_to_kminrob_path(problem_path)
    with open(kminrob_problem_path, 'w+') as kminrob_problem_file, open(problem_path) as problem_file:
        for line in problem_file:
            index = line.find(';')
            if index != -1:
                line = line[:index] + '\n'
            if line.strip() == '':
                continue
            index = line.find('(:init')
            if index == -1:
                kminrob_problem_file.write(line)
            else:
                index += 6
                kminrob_problem_file.write(line[:index] + '\n')
                kminrob_line = '\t\t(design) '
                for fluent in helper_knowledge:
                    kminrob_line += fluent_to_acquisition_fluent(fluent) + ' '
                kminrob_problem_file.write(
                    kminrob_line + '\n\t' + line[index:])
                break
        for line in problem_file:
            index = line.find(';')
            if index != -1:
                line = line[:index] + '\n'
            if line.strip() == '':
                continue
            kminrob_problem_file.write(line)
    return kminrob_problem_path


def convert_to_kminrob_files(domain_path: str, problem_path: str, helper_knowledge: str) -> Tuple[str, str]:
    kminrob_domain_path = write_kminrob_domain(domain_path)
    kminrob_problem_path = write_kminrob_problem(
        problem_path, helper_knowledge)
    return kminrob_domain_path, kminrob_problem_path


def solve(solver_path: str, domain_path: str, problem_path: str, planner_type: str, objective: str, robustness: float, index: int) -> Tuple:
    compilation = 'kminrob'

    start_time = time.time()

    solution_file_path = os.path.join(
        defs_apk.get_gen_folder_name(), 'kp_output_PO_%d_kminrob.txt' % index)

    if defs_apk.FD.lower() in planner_type.split(':')[0].lower():
        planner_path = defs_apk.FD_PATH

    elif defs_apk.FF.lower() in planner_type.split(':')[0].lower():
        planner_path = defs_apk.FF_PATH

    cmd = f'{solver_path}/K_replanner --domain {domain_path} --problem {problem_path} --planner {planner_type} --planner-path {planner_path} --compilation {compilation} --keep-intermediate-files --no-replan --tmpfile-path {defs_apk.get_gen_folder_name()}'
    if len(objective) > 1:
        cmd += f' --objective {objective}'
    if robustness is None:
        robustness = 0
    cmd += f' --robustness {robustness}'
    cmd += f' > {solution_file_path}'

    print('\033[1mcmd solver k-replanner:\033[0m', cmd)
    print('\033[1mcwd:\033[0m', os.getcwd())

    utils_apk.run(cmd, solver_path)

    plans, has_solution, plan_cost = read_optimistic_plans(solution_file_path)
    if has_solution:
        plan, plan_cost = plans[0]
    else:
        plan, plan_cost = [defs_apk.FAILURE_STRING], defs_apk.INFINITE
    print('\033[1mplan:\033[0m', plan)

    assumptions = None
    number_of_assumptions = 0
    assumptions, number_of_assumptions = parse_assumptions(solution_file_path)

    belief_states = None
    belief_states = parse_beliefs(solution_file_path)

    calc_time = time.time() - start_time
    logging.info('InMethod solve: index:%d, has_solution:%s, number_of_planner_calls:%d, number_of_assumptions:%d, plan_length:%d, calc_time=%.2f' % (
        index, has_solution, 1, number_of_assumptions, plan_cost, calc_time))
    logging.debug(compilation)
    logging.debug('po_plan')
    logging.debug(plan)

    return plan, has_solution, plan_cost, assumptions, belief_states


def solver_his_rob(solver_path, domain_path, problem_path, design_domain_path, design_problem_path, hyp_index, hidden_facts, planner_type, robustness, objective='', knowledge_acquisition: bool = True) -> Tuple:
    if knowledge_acquisition:
        helper_knowledge = get_helper_knowledge(design_domain_path, design_problem_path, hidden_facts)
        kminrob_domain_path, kminrob_problem_path = convert_to_kminrob_files(domain_path, problem_path, helper_knowledge)
    else:
        kminrob_domain_path, kminrob_problem_path = domain_path, problem_path
    po_plan, has_solution, _, _, _ = solve(solver_path, kminrob_domain_path, kminrob_problem_path, planner_type, objective, robustness, hyp_index)
    cost = 0 if has_solution else defs_apk.INFINITE
    plan = list()
    acquired_knowledge = list()
    if has_solution:
        if type(po_plan[0]) == list:
            traceback.print_stack()
            embed()
            warnings.warn(f'plan is list of list, plan={po_plan}. Changing to po_plan=po_plan[0]')
            po_plan = po_plan[0]
        plan_index = 0
        plan_length = len(po_plan)
        while plan_index < plan_length:
            step = po_plan[plan_index]
            plan_index += 1
            if step == 'switch_from_design':
                break
            knowledge = step[20:]
            if knowledge.startswith('true-'):
                knowledge = knowledge[5:]
            else:
                knowledge = 'not-' + knowledge[6:]
            acquired_knowledge.append(knowledge)
        while plan_index < plan_length:
            step = po_plan[plan_index]
            if not step.startswith('sensor-'):
                plan.append(step)
            plan_index += 1
        if knowledge_acquisition:
            acquired_knowledge = kac_to_fluents(acquired_knowledge, helper_knowledge)
    return has_solution, plan, acquired_knowledge, cost, len(plan)
