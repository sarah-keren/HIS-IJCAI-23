
#include <boost/program_options.hpp>
#include <boost/filesystem.hpp>

#include <iostream>
#include "planners/planner_factory.h"
#include "CompiledProblem.h"
#include "compilations/compiler.h"
#include "problem/Problem.h"
#include "replanner.h"

namespace po = boost::program_options;
using namespace std;

int main(int argc, char *argv[]) {
    po::options_description desc("Allowed options");
    desc.add_options()
            ("help,H", "produce help message")
            ("domain", po::value<string>()->required(), "path to the domain file to solve")
            ("problem", po::value<string>()->required(), "path to the problem file to solve")
            ("planner", po::value<string>()->default_value("fd"), "set planner to use")
            ("planner-path", po::value<string>()->required(), "path to directory of the planner to use")
            ("compilation", po::value<string>()->default_value("kp"), "The compilation to use")
            ("objective", po::value<string>()->default_value(""), "The objective of the agent")
            ("robustness", po::value<float>()->default_value(0.0), "required minimum level of robustness")
            ("keep-intermediate-files", po::bool_switch(), "Keep the compiled files after solving")
            ("no-replan", po::bool_switch(), "plain only once for the compiled probblem")
            ("tmpfile-path", po::value<string>()->default_value(boost::filesystem::current_path().string()),
             "Path for tmp files");
    po::variables_map vm;
    try {
        po::store(po::parse_command_line(argc, argv, desc), vm);
        po::notify(vm);
        if (vm.count("help")) {
            std::cout << desc << std::endl;
            return 1;
        }

    } catch (const boost::program_options::required_option &e) {
        if (vm.count("help")) {
            std::cout << desc << std::endl;
            return 1;
        } else {
            throw e;
        }
    }

    if (vm.count("help") || argc == 0) {
        cout << desc << "\n";
        return 0;
    }

    auto &tmp_path = vm["tmpfile-path"].as<string>();
    auto &keep_files = vm["keep-intermediate-files"].as<bool>();

    Planner *planner = planner_factory(vm["planner"].as<string>(), vm["planner-path"].as<string>());

    Problem problem(vm["domain"].as<string>(), vm["problem"].as<string>());

    auto &robustness = vm["robustness"].as<float>();
    std::map<string, string> options = {{"robustness", std::to_string(robustness)},
                                        {"objective", vm["objective"].as<string>()}};

    auto &compilation = vm["compilation"].as<std::string>();

    auto compiled_problem = compiler(problem, compilation, options);

    problem.clear();

    compiled_problem->optimize();

    auto &no_replan = vm["no-replan"].as<bool>();
    bool optimize = false;
    replanner(compiled_problem, planner, tmp_path, keep_files, optimize, no_replan);

    delete compiled_problem;
    delete planner;

    return 0;
}