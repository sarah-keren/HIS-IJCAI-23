

#ifndef REPLANNER_FASTDOWNWARD_H
#define REPLANNER_FASTDOWNWARD_H

#include "Planner.h"

class FastDownward : public Planner {
private:

    string executablePath, search;

    std::deque<string> parse_planner_plan(const string &plan_path) override;

public:
    FastDownward(string executablePath, const string &planner_config);

    ~FastDownward() override = default;

    std::deque<string> solve(string destination, string domain, string problem) override;

};


#endif //REPLANNER_FASTDOWNWARD_H
