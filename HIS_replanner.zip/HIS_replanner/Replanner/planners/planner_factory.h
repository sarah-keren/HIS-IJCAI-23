
#ifndef REPLANNER_PLANNER_FACTORY_H
#define REPLANNER_PLANNER_FACTORY_H

#include <stdexcept>
#include <algorithm>
#include <map>

#include "FastDownward.h"
#include "FastForward.h"
#include "../utils.h"


Planner *planner_factory(std::string name, const std::string &planner_path) {
    Planner *planner = nullptr;
    boost::to_lower(name);
    auto parts = split(name, ':');
    std::string planner_name = parts.at(0), configuration = parts.size() > 1 ? parts.at(1) : "";
    if (planner_name.find("fd") == 0) {
        planner = new FastDownward(planner_path, configuration);
    } else if (planner_name.find("ff") == 0) {
        planner = new FastForward(planner_path, configuration);
    } else {
        throw std::invalid_argument(planner_name + "is unsupported planner!");
    }
    return planner;
}

#endif //REPLANNER_PLANNER_FACTORY_H
