
#include "FastForward.h"
#include <boost/filesystem.hpp>
#include "../utils.h"

#include <utility>

FastForward::FastForward(string executablePath, string planner_config) : executable_path(
        join_path({std::move(executablePath), "ff"})), configuration(std::move(planner_config)) {

}

std::deque<string> FastForward::solve(string destination, string domain, string problem) {
    auto output_path = join_path({destination, "ff_output"});
    string cmd = executable_path + " -o " + domain + " -f " + problem + " " + configuration + " > " + output_path;
    std::deque<string> plan;
    auto return_value = system(cmd.c_str());
    if (return_value == 0) {
        plan = parse_planner_plan("sas_plan");
    }
    remove(output_path.c_str());
    return plan;
}

std::deque<string> FastForward::parse_planner_plan(const string &plan_path) {
    string base_dir = boost::filesystem::path(plan_path).parent_path().string();
    auto tmp_1_plan = join_path({base_dir, "tmp_1_ff_output"});
    auto tmp_2_plan = join_path({base_dir, "tmp_2_ff_output"});
    string command = "egrep -e \"[0-9]+:\" " + plan_path + " > " + tmp_1_plan;
    std::deque<string> plan;
    if (system(command.c_str()) != 0) {
        remove(tmp_1_plan.c_str());
        return plan;
    }
    command = "cat " + tmp_1_plan + R"( |  awk '{print $NF;}' | tr "[:upper:]" "[:lower:]" > )" + tmp_2_plan;
    int return_value = system(command.c_str());
    remove(tmp_1_plan.c_str());
    if (return_value != 0) {
        remove(tmp_2_plan.c_str());
        return plan;
    }
    boost::filesystem::remove(tmp_1_plan);
    std::ifstream plan_file(tmp_2_plan);
    string line;
    while (!plan_file.eof()) {
        getline(plan_file, line);
        if (!line.empty())
            plan.push_back(line);
    }
    plan_file.close();
    boost::filesystem::remove(tmp_2_plan);
    return plan;
}