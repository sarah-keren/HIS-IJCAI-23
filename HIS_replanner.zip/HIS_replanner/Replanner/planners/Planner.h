
#ifndef REPLANNER_PLANNER_H
#define REPLANNER_PLANNER_H

#include <string>
#include <deque>
#include "../problem/Problem.h"

using std::string;


class Planner {
protected:
    Planner() = default;

    virtual std::deque<string> parse_planner_plan(const string &plan_path) = 0;


public:

    virtual ~Planner() = default;

    virtual std::deque<string> solve(string destination, string domain, string problem) = 0;

};


#endif //REPLANNER_PLANNER_H
