
#ifndef REPLANNER_FASTFORWARD_H
#define REPLANNER_FASTFORWARD_H

#include "Planner.h"


class FastForward : public Planner {

private:

    string executable_path, configuration;

    std::deque<string> parse_planner_plan(const string &plan_path) override;

public:

    FastForward(string executablePath, string planner_config);

    ~FastForward() override = default;

    std::deque<string> solve(string destination, string domain, string problem) override;
};


#endif //REPLANNER_FASTFORWARD_H
