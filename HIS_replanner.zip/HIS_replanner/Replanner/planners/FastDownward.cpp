
#include "FastDownward.h"
#include "../utils.h"
#include <utility>
#include <iostream>
#include <fstream>
#include <filesystem>

FastDownward::FastDownward(string executablePath, const string &planner_config) : executablePath(
        join_path({std::move(executablePath), "fast-downward.py"})) {
    if (planner_config.find("hmaxnocachetrans") != std::string::npos) {
        search = "--search \"astar(hmax(transform=adapt_costs(NORMAL), cache_estimates=false))\"";
    } else if (planner_config.find("hmaxcachetrans") != std::string::npos) {
        search = "--search \"astar(hmax(transform=adapt_costs(NORMAL), cache_estimates=true))\"";
    } else if (planner_config.find("hmaxnocache") != std::string::npos) {
        search = "--search \"astar(hmax(transform=no_transform(), cache_estimates=false))\"";
    } else if (planner_config.find("hmax") != std::string::npos) {
        search = "--search \"astar(hmax(transform=no_transform(), cache_estimates=true))\"";
    } else if (planner_config.find("fftrans") != std::string::npos)
        search = " --search \"astar(ff(transform=adapt_costs(NORMAL), cache_estimates=true))\"";
    else if (planner_config.find("fftransnocache") != std::string::npos) {
        search = " --search \"astar(ff(transform=adapt_costs(NORMAL), cache_estimates=false))\"";
    } else if (planner_config.find("fftranscache") != std::string::npos) {
        search = " --search \"astar(ff(transform=adapt_costs(NORMAL), cache_estimates=true))\"";
    } else if (planner_config.find("ff") != std::string::npos) {
        search = " --search \"astar(ff(transform=adapt_costs(NORMAL), cache_estimates=true))\"";
    } else if (planner_config.find("lmcut") != std::string::npos) {
        search = " --search \"astar(lmcut())\"";
    } else {
        search = " --search \"astar(hmax(transform=adapt_costs(NORMAL), cache_estimates=true))\"";
    }
}

std::deque<string> FastDownward::solve(string destination, string domain, string problem) {
    auto current_path = std::filesystem::current_path();
    // destination = std::filesystem::absolute(destination);
    domain = std::filesystem::absolute(domain);
    problem = std::filesystem::absolute(problem);
    const string fd_output_path = "fd_output";
    const string plan_path = "sas_plan";
    std:: cout << "Current path is: " << current_path << std::endl;
    std::filesystem::current_path(destination);
    string cmd = executablePath + ' ' + domain + ' ' + problem + " " + search + " > " + fd_output_path;
    std::cout << "Command is \"" << cmd << '\"' << std::endl;
    std::deque <string> plan;
    auto return_value = system(cmd.c_str());
    if (return_value == 0) {
        plan = parse_planner_plan(plan_path);
    }
    remove(plan_path.c_str());
    std::filesystem::current_path(current_path);
    return plan;
}

std::deque<string> FastDownward::parse_planner_plan(const string &plan_path) {
    std::deque<string> plan;
    std::ifstream plan_file(plan_path);
    if (!plan_file.good()) {
        return plan;
    }
    string line;
    while (!plan_file.eof()) {
        getline(plan_file, line);
        if (line.at(0) != ';')
            plan.push_back(line.substr(1, line.size() - 3));
        else
            break;
    }
    plan_file.close();
    return plan;
}