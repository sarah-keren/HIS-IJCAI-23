
#ifndef REPLANNER_TYPE_H
#define REPLANNER_TYPE_H

#include <string>
#include <set>
#include <ostream>

#include "Parameter.h"
#include "PDDL_Object.h"

class PDDL_Object;
class Parameter;

using std::string;


class Type {

private:
    string name;
    Type *const parent;
    std::set<Type *> descendants;
    std::set<PDDL_Object *> objects;

public:
    Type(string name, Type *parent);

    explicit Type(string name);

    void add_descendant(Type *descendant);

    void add_object(PDDL_Object *object);

    bool is_compatible(Type *type);

    std::set<PDDL_Object *> getObjects() const;

    const string &getName() const;

    Parameter *get_parameter(const std::string &parameter_name);

    friend std::ostream &operator<<(std::ostream &os, const Type &type);

};


#endif //REPLANNER_TYPE_H
