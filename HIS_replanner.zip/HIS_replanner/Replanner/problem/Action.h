
#ifndef REPLANNER_ACTION_H
#define REPLANNER_ACTION_H

#include <ostream>
#include "Formula.h"
#include "Term.h"
#include "Parameter.h"
#include "Type.h"
#include "Predicate.h"

class Type;


class Action {
private:
    std::string name;
    std::map<std::string, Parameter *> parameters_map;
    Formula *precondition, *effect;
    std::deque<std::string> parameters_order;

    void parse_parameters(const Term *pTerm, const std::map<std::string, Type *> &types_map);

public:
    Action(const Term *term, const std::map<std::string, Type *> &types_map,
           const std::map<std::string, Predicate *> &predicates_map,
           const std::map<std::string, PDDL_Object *> &constants_map);

    Action(std::string name, std::map<std::string, Parameter *> parametersMap, Formula *precondition,
           Formula *effect);

    virtual ~Action();

    Formula *getPrecondition() const;

    void setPrecondition(Formula *new_precondition);

    Formula *getEffect() const;

    void setEffect(Formula *new_effect);

    const string &getName() const;

    void add_parameter(Parameter* parameter);

    std::deque<Parameter *> getParameters() const;

    friend std::ostream &operator<<(std::ostream &os, const Action &action1);

};


#endif //REPLANNER_ACTION_H
