

#ifndef REPLANNER_PDDL_OBJECT_H
#define REPLANNER_PDDL_OBJECT_H

//#include <string>
#include <ostream>
#include "Type.h"

//using std::string;

class Type;


class PDDL_Object {

private:
    const std::string name;
    Type *const object_type;

public:

    PDDL_Object(std::string name, Type *type);

    Type *getType() const;

    const std::string &getName() const;

    friend std::ostream &operator<<(std::ostream &os, const PDDL_Object &object);

};


#endif //REPLANNER_PDDL_OBJECT_H
