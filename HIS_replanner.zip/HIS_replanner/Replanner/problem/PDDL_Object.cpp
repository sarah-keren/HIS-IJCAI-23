
#include "PDDL_Object.h"

#include <utility>

PDDL_Object::PDDL_Object(string name, Type *const type) : name(std::move(name)), object_type(type) {}

Type *PDDL_Object::getType() const {
    return object_type;
}

const string &PDDL_Object::getName() const {
    return name;
}

std::ostream &operator<<(std::ostream &os, const PDDL_Object &object) {
    os << object.name;
    return os;
}
