

#include "Parameter.h"

#include <utility>

Parameter::Parameter(const Type *type, std::deque<PDDL_Object *> compatibleObjects, string name) : type(
        type), compatible_objects(std::move(compatibleObjects)), name(std::move(name)) {}

void Parameter::remove_compatible_object(PDDL_Object *object) {
    auto end = compatible_objects.end();
    for (auto i = compatible_objects.begin(); i != end;) {
        if (*i == object) {
            compatible_objects.erase(i);
            break;
        }
    }
}

void Parameter::add_compatible_object(PDDL_Object *object) {
    compatible_objects.push_back(object);
}

const std::deque<PDDL_Object *> &Parameter::getCompatibleObjects() const {
    return compatible_objects;
}

const Type *Parameter::getType() const {
    return type;
}

const string &Parameter::getName() const {
    return name;
}

std::ostream &operator<<(std::ostream &os, const Parameter &parameter) {
    os << parameter.name;
    return os;
}
