
#ifndef REPLANNER_VARIABLE_H
#define REPLANNER_VARIABLE_H

#include <string>
#include "Type.h"
#include "PDDL_Object.h"

//using std::string;


class Variable {

private:

    const string name;
    Type *const type;

public:
    Variable(string name, Type *type);

    bool is_compatible(PDDL_Object * object);

};


#endif //REPLANNER_VARIABLE_H
