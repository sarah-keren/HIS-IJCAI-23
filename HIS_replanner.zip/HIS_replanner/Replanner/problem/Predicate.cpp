

#include "Predicate.h"
#include "../utils.h"

#include <utility>

Predicate::Predicate(const Term &term, const std::map<std::string, Type *> &types_map) {
    auto parts = get_words(term.getContent());
    std::string word;
    auto n = parts.size();
    short type_variables_counter = 0, j;
    name = std::string(parts.at(0));
    for (int i = 1; i < n; ++i) {
        word = parts.at(i);
        if (word == "-") {
            word = parts.at(++i);
            for (j = 0; j < type_variables_counter; ++j) {
                variables.push_back(types_map.at(word));
            }
            type_variables_counter = 0;
        } else
            type_variables_counter++;
    }
    for (j = 0; j < type_variables_counter; ++j) {
        variables.push_back(types_map.at("object"));
    }
}

Predicate::Predicate(string name, bool isChangeable) : name(std::move(name)), is_changeable(isChangeable) {}

bool Predicate::isChangeable() const {
    return is_changeable;
}

void Predicate::setIsChangeable(bool isChangeable) {
    is_changeable = isChangeable;
}

bool Predicate::isObservable() const {
    return is_observable;
}

void Predicate::setIsObservable(bool isObservable) {
    is_observable = isObservable;
}

bool Predicate::isDeducible() const {
    return is_deducible;
}

void Predicate::setIsDeducible(bool isDeducible) {
    is_deducible = isDeducible;
}

const std::deque<Type *> &Predicate::getVariables() const {
    return variables;
}

const string &Predicate::getName() const {
    return name;
}

void Predicate::add_derived_predicate(Predicate *predicate) {
    derived_predicates.insert(predicate);
    predicate->setIsChangeable(is_changeable);
    predicate->setIsDeducible(is_deducible);
    predicate->setIsObservable(is_observable);
}

void Predicate::erase_derived_predicate(Predicate *predicate) {
    auto it = derived_predicates.find(predicate);
    if (it != derived_predicates.end()) {
        derived_predicates.erase(it);
    }
}

std::ostream &operator<<(std::ostream &os, const Predicate &predicate) {
    os << '(' << predicate.getName();
    auto variables = predicate.variables;
    auto n = variables.size();
    for (int i = 0; i < n; ++i) {
        os << " ?p" << i << " - " << variables.at(i)->getName();
    }
    os << ')';
    return os;
}
