

#ifndef REPLANNER_BUDGET_H
#define REPLANNER_BUDGET_H


#include <string>
#include "Type.h"

class Budget {
private:
    const std::string budget_name, budget_type_name;
    float budget_value;
    Type *budget_type;

public:
    Budget(std::string budgetName, float budgetValue);

    const std::string &getBudgetName() const;

//    size_t getBudgetValue() const;

//    std::string get_type() const;

    std::string get_objects() const;

    std::string get_predicate() const;

    Type *getBudgetType() const;

    bool decrease();

    bool reached_maximum() const;

};


#endif //REPLANNER_BUDGET_H
