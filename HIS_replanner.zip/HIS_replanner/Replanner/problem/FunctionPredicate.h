
#ifndef REPLANNER_FUNCTIONPREDICATE_H
#define REPLANNER_FUNCTIONPREDICATE_H

#include <ostream>
#include "Predicate.h"
#include "Parameter.h"
//#include "Function.h"


class FunctionPredicate : public Predicate {
public:
    FunctionPredicate(const Term &term, const std::map<std::string, Type *> &typesMap);

    FunctionPredicate(const string &name, std::deque<Type *> variables);

    friend std::ostream &operator<<(std::ostream &os, const FunctionPredicate &predicate);

};


#endif //REPLANNER_FUNCTIONPREDICATE_H
