
#include "FunctionFormula.h"

FunctionFormula::FunctionFormula(Function *function, std::deque<Parameter *> parameters, size_t value)
        : function(function), parameters(std::move(parameters)), value(value) {}

FunctionFormula::FunctionFormula(const FunctionFormula &formula) = default;

Function *FunctionFormula::getFunction() const {
    return function;
}

size_t FunctionFormula::getValue() const {
    return value;
}

std::ostream &operator<<(std::ostream &os, const FunctionFormula &functionFormula) {
    os << "(increase " << *functionFormula.function << ' ' << functionFormula.value << ')';
    return os;
}
