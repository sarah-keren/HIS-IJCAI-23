
#include "FunctionPredicate.h"

FunctionPredicate::FunctionPredicate(const Term &term, const std::map<std::string, Type *> &typesMap) : Predicate(term,
                                                                                                                  typesMap) {}

FunctionPredicate::FunctionPredicate(const string &name, std::deque<Type *> variables) : Predicate(name, false) {
    this->variables.insert(this->variables.begin(), variables.begin(), variables.end());
}

std::ostream &operator<<(std::ostream &os, const FunctionPredicate &predicate) {
    os << static_cast<const Predicate &>(predicate);
    return os;
}
