
#ifndef REPLANNER_FACT_H
#define REPLANNER_FACT_H

#include <ostream>
#include "Predicate.h"
#include "PDDL_Object.h"

class Predicate;


class Fact {
private:
    Predicate *predicate;
    std::deque<PDDL_Object *> objects;
    bool state;
public:
    Fact(Predicate *const predicate, std::deque<PDDL_Object *> objects, bool state);

//    Fact(Predicate *const predicate, const std::deque<PDDL_Object *> &objects);

//    Fact(Term *term, const std::map<string, Predicate *> &predicates_map,
//         const std::map<string, PDDL_Object *> &objects_map, const std::map<string, PDDL_Object *> &constants_map);

    virtual ~Fact();

    Fact(const Fact &another_fact);

    Predicate *getPredicate() const;

    const std::deque<PDDL_Object *> &getObjects() const;

    bool getState() const;

//    void setState(bool new_state);

    bool isTheSame(const Fact &fact) const;

    bool operator==(const Fact &rhs) const;

    bool operator!=(const Fact &rhs) const;

    friend std::ostream &operator<<(std::ostream &os, const Fact &fact);

    std::string to_string() const;
};


#endif //REPLANNER_FACT_H
