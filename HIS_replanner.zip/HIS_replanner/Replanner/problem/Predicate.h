

#ifndef REPLANNER_PREDICATE_H
#define REPLANNER_PREDICATE_H

#include <ostream>
#include "Type.h"
#include "Parameter.h"
#include "Term.h"
#include "Fact.h"

class Fact;


class Predicate {
private:
    std::set<Predicate *> derived_predicates;
protected:
    std::deque<Type *> variables;
    std::string name;
    bool is_changeable = false, is_observable = false, is_deducible = false;
public:
    Predicate(const Term &term, const std::map<std::string, Type *> &types_map);

    Predicate(string name, bool isChangeable);

    bool isChangeable() const;

    void setIsChangeable(bool isChangeable);

    bool isObservable() const;

    void setIsObservable(bool isObservable);

    bool isDeducible() const;

    void setIsDeducible(bool isDeducible);

    const std::deque<Type *> &getVariables() const;

    const string &getName() const;

    void add_derived_predicate(Predicate *predicate);

    void erase_derived_predicate(Predicate *predicate);

    friend std::ostream &operator<<(std::ostream &os, const Predicate &predicate);

};


#endif //REPLANNER_PREDICATE_H
