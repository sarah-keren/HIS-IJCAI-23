
#ifndef REPLANNER_INVARIANT_H
#define REPLANNER_INVARIANT_H

#include <ostream>
#include "Fact.h"


class Invariant {
private:
    std::deque<Fact *> facts;
public:
    explicit Invariant(const std::deque<Fact *> &facts);

//    Invariant(const Term *term, const std::map<string, Predicate *> &predicates_map,
//              const std::map<string, PDDL_Object *> &objects_map);

    virtual ~Invariant();

    const std::deque<Fact *> &getFacts() const;

    std::string to_string() const;

    friend std::ostream &operator<<(std::ostream &os, const Invariant &invariant);
};


#endif //REPLANNER_INVARIANT_H
