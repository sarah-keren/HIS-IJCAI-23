
#include "Fact.h"
#include "../utils.h"

#include <utility>
#include <sstream>

Fact::Fact(Predicate *const predicate, std::deque<PDDL_Object *> objects, bool state) : predicate(predicate),
                                                                                        objects(std::deque<PDDL_Object *>(
                                                                                                std::move(objects))),
                                                                                        state(state) {}

//Fact::Fact(Predicate *const predicate, const std::deque<PDDL_Object *> &objects) : Fact(predicate, objects, true) {}

Fact::Fact(const Fact &another_fact) : predicate(another_fact.predicate),
                                       objects(std::deque<PDDL_Object *>(another_fact.objects)),
                                       state(another_fact.state) {}

//Fact::Fact(Term *term, const std::map<string, Predicate *> &predicates_map,
//           const std::map<string, PDDL_Object *> &objects_map, const std::map<string, PDDL_Object *> &constants_map) {
//    std::string name;
//    PDDL_Object *object;
//    auto parts = get_words(term->getContent());
//    if (parts.at(0) == "not") {
//        state = false;
//        term = term->getInnersTerms(TermType::formula)->at(0);
//        parts = get_words(term->getContent());
//    } else {
//        state = true;
//    }
//    predicate = predicates_map.at(parts.at(0));
//    auto n = parts.size();
//    for (int i = 1; i < n; ++i) {
//        name = parts.at(i);
//        auto it_obj = objects_map.find(name);
//        object = it_obj == objects_map.end() ? constants_map.at(name) : it_obj->second;
//        objects.push_back(object);
//    }
//}

Fact::~Fact() {
    objects.clear();
    predicate = nullptr;
}

bool Fact::getState() const {
    return state;
}

//void Fact::setState(bool new_state) {
//    state = new_state;
//}

Predicate *Fact::getPredicate() const {
    return predicate;
}

const std::deque<PDDL_Object *> &Fact::getObjects() const {
    return objects;
}

bool Fact::isTheSame(const Fact &fact) const {
    return (predicate == fact.predicate) && (objects == fact.objects);
}

bool Fact::operator==(const Fact &rhs) const {
    return isTheSame(rhs) && state == rhs.state;
}

bool Fact::operator!=(const Fact &rhs) const {
    return !(rhs == *this);
}

std::ostream &operator<<(std::ostream &os, const Fact &fact) {
    short parenthesis = 1;
    if (!fact.state) {
        os << "(not ";
        parenthesis = 2;
    }
    os << '(' << fact.predicate->getName();
    for (const auto &object: fact.objects) {
        os << ' ' << object->getName();
    }
    os << std::string(parenthesis, ')');
    return os;
}

std::string Fact::to_string() const {
    std::stringstream stringstream;
    stringstream << *this;
    return stringstream.str();
}
