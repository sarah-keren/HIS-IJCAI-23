
#include "Variable.h"

#include <utility>

Variable::Variable(string name, Type *const type) : name(std::move(name)), type(type) {}

bool Variable::is_compatible(PDDL_Object *object) {
    return type->is_compatible(object->getType());
}
