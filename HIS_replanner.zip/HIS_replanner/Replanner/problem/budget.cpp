

#include "budget.h"

#include <utility>

Budget::Budget(std::string budgetName, float budgetValue) : budget_name(std::move(budgetName)),
                                                          budget_value(budgetValue), budget_type_name(budget_name + "_type") {
    budget_type = new Type(budget_type_name);
}

const std::string &Budget::getBudgetName() const {
    return budget_name;
}

//size_t Budget::getBudgetValue() const {
//    return budget_value;
//}

//std::string Budget::get_type() const {
//    return budget_name;
//}

std::string Budget::get_objects() const {
    std::string objects;
    auto n = long (budget_value);
        if (n > 0) {
        for (int i = 0; i < n; ++i) {
            objects += budget_name + '_' + std::to_string(i) + ' ';
        }
        objects += "- " + budget_type_name;
    }
    return objects;
}

std::string Budget::get_predicate() const {
    return "(" + budget_name + " ?b - " + budget_type_name + ')';
}

Type *Budget::getBudgetType() const {
    return budget_type;
}

bool Budget::decrease() {
    return budget_value-- >= 0;
}

bool Budget::reached_maximum() const {
    return budget_value < 0;
}
