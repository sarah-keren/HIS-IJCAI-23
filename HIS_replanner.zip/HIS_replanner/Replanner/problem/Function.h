
#ifndef REPLANNER_FUNCTION_H
#define REPLANNER_FUNCTION_H

#include <ostream>
#include "FunctionPredicate.h"
#include "PDDL_Object.h"


class Function {
private:
    std::string function_metric, name;
    size_t function_value = 0;
    bool has_metric = false;
    const std::deque<PDDL_Object *> objects;
    // std::map<std::string, int (*)(int, int)> operators_map;
public:

    Function(string name, std::deque<PDDL_Object *> objects, size_t functionValue);

    Function(FunctionPredicate &functionPredicate, std::deque<PDDL_Object *> objects);

    explicit Function(const std::string &name);

    size_t getFunctionValue() const;

    void setFunctionValue(size_t functionValue);

    const string &getFunctionMetric() const;

    void setFunctionMetric(const string &metric);

    const string &getName() const;

    bool isHasMetric() const;

    void print_value(std::ostream &os) const;

    void print_metric(std::ostream &os) const;

    // void operate(const std::string &operator_name, int value);

    void increase(const size_t &value);

    friend std::ostream &operator<<(std::ostream &os, const Function &function);

};


#endif //REPLANNER_FUNCTION_H
