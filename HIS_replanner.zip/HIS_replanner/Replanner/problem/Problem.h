
#ifndef REPLANNER_PROBLEM_H
#define REPLANNER_PROBLEM_H

#include "Action.h"
#include "Sensor.h"
#include "Formula.h"
#include "Fact.h"
#include "Predicate.h"
// #include "ProbabilityFact.h"
#include "Invariant.h"

class Problem {
private:
    std::string problem_name, domain_name;
    std::deque<Fact *> facts, hidden, goal, unknown_facts;
    // std::deque<ProbabilityFact *> unknown;
    std::deque<Action *> actions;
    std::deque<Sensor *> sensors;
    std::deque<Invariant *> invariants;
    std::map<std::string, Type *> types_map;
    std::map<std::string, PDDL_Object *> objects_map, constants_map;
    std::map<std::string, Predicate *> predicates_map;
    std::deque<std::string> requirements;
    std::map<std::string, std::map<std::deque<std::string>, std::map<bool, Fact *>>> fact_map;

    static std::stringstream remove_comments(const string &path);

    void types_processing(const Term *&types_term);

    void objects_processing(const Term *&objects_term);

    void constants_processing(const Term *&constants_term);

    void predicates_processing(const Term *&predicate_term);

    void init_processing(const Term *&init_term);

    void hidden_processing(const Term *&hidden_term);

    void goal_processing(Term *&goal_term);

    void domain_to_pddl(const string &destination, const string &domainName);

    void problem_to_pddl(const string &destination, const string &problemName);

    Fact *get_fact(const std::string &predicate_name, const std::deque<std::string> &objects_name, bool state);

    Fact *fact_processing(Term *fact_term);

public:
    Problem(const std::string &domain_path, const std::string &problem_path);

    virtual ~Problem();

    void clear();

    const string &getProblemName() const;

    const string &getDomainName() const;

    const std::deque<Fact *> &getInit() const;

    const std::deque<Fact *> &getHidden() const;

    const std::deque<Fact *> &getGoal() const;

    const std::deque<Action *> &getActions() const;

    const std::deque<Sensor *> &getSensors() const;

    const std::deque<Invariant *> &getInvariants() const;

    const std::map<std::string, Type *> &getTypesMap() const;

    const std::map<std::string, PDDL_Object *> &getObjectsMap() const;

    const std::map<std::string, PDDL_Object *> &getConstantsMap() const;

    const std::map<std::string, Predicate *> &getPredicatesMap() const;

    const std::deque<std::string> &getRequirements() const;

    const std::deque<Fact *> &getUnknownFacts() const;

    void to_pddl(const std::string &destination, const std::string &problemName, const std::string &domainName);

};


#endif //REPLANNER_PROBLEM_H
