
#ifndef REPLANNER_FUNCTIONFORMULA_H
#define REPLANNER_FUNCTIONFORMULA_H

#include <ostream>
#include "Function.h"
#include "Parameter.h"


class FunctionFormula {
private:
    Function *function;
    std::deque<Parameter *> parameters;
    size_t value;
public:
    FunctionFormula(Function *function, std::deque<Parameter *> parameters, size_t value);

    FunctionFormula(const FunctionFormula &formula);

    Function *getFunction() const;

    size_t getValue() const;

    friend std::ostream &operator<<(std::ostream &os, const FunctionFormula &functionFormula);

};


#endif //REPLANNER_FUNCTIONFORMULA_H
