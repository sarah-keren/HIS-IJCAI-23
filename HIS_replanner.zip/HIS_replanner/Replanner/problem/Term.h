
#ifndef REPLANNER_TERM_H
#define REPLANNER_TERM_H

#include <iostream>
#include <deque>
#include <map>
#include <boost/algorithm/string.hpp>

enum TermType {
    action,
    constants,
    define,
    domain,
    formula,
    goal,
    hidden,
    init,
    objects,
    predicates,
    problem,
    requirements,
    sensor,
    types,
};

class Term {
private:
    std::string content;
    TermType type;
    std::map<TermType, std::deque<Term *> *> inners_terms;

    void calculate_type();

public:

    Term();

    Term(std::string content, TermType type, std::map<TermType, std::deque<Term *> *> inners);

    explicit Term(const std::string &full_content);

    virtual ~Term();

    void clear();

    friend std::istream &operator>>(std::istream &input, Term &term);

    TermType getType() const;

    std::deque<Term *> *getInnersTerms(const TermType &termType) const;

    const std::string &getContent() const;


};


#endif //REPLANNER_TERM_H
