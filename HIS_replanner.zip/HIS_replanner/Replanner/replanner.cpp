
#include "replanner.h"
#include "utils.h"

using namespace std;


void replanner(CompiledProblem *problem, Planner *planner, const string &tmp_path, const bool &keep_files, const bool &optimize, const bool &no_replan) {
    std::cout << "Starting replanning process" << std::endl;
    const clock_t begin_time = clock();
    std::deque<std::string> running_plan, assumptions, plan;
    const Action *action;
    Formula *preconditions_formula;
    std::deque<Formula *> preconditions;
    std::deque<const Action *> reduced_plan;
    auto id = std::to_string(getpid());
    short counter = 0;
    size_t i, n;
    std::string counter_str, problem_name, domain_name, problem_path, domain_path;
    problem->deduce();
    std::cout << ">>>> initial state=";
    print_state(problem);
    auto basic_problem_name = "gen-p" + id + "-";
    auto basic_domain_name = "gen-d" + id + "-";
    bool replaned = false;
    while ((!problem->is_goal_reached()) && !(no_replan && replaned)) {
        counter_str = std::to_string(counter++);
        problem_name = basic_problem_name + counter_str + ".pddl";
        domain_name = basic_domain_name + counter_str + ".pddl";
        if (optimize) {
            problem->optimize();
        }
        problem->to_pddl(tmp_path, problem_name, domain_name);
        problem_path = join_path({tmp_path, problem_name});
        domain_path = join_path({tmp_path, domain_name});
        cout << "before calling planner" << endl;
        running_plan = planner->solve(tmp_path, domain_path, problem_path);
        replaned = true;
        reduced_plan.clear();
        if (!keep_files) {
            remove(domain_path.c_str());
            remove(problem_path.c_str());
        }
        if (running_plan.empty()) {
            std::cout << "problem has no solution!" << endl;
            return;
        }
        for (const auto &step: running_plan) {
            cout << step << endl;
            if (step.find("assume-") != 0 && step.find("invariant-at-least-one-") != 0 && step.find("sensor-") != 0) {
                reduced_plan.push_back(problem->get_action(step));
            }
        }
        cout << "Classical plan (raw):" << endl;
        n = running_plan.size();
        for (i = 0; i < n; ++i) {
            cout << "\tstep " << i << ": ." << running_plan.at(i) << endl;
        }
        n = reduced_plan.size();
        cout << "Classical plan (reduced):" << endl;
        for (i = 0; i < n; ++i) {
            cout << "\tstep " << i << ": ." << reduced_plan.at(i)->getName() << endl;
        }
        cout << "after calling planner" << endl;
        cout << "Assumptions:" << endl;
        for (i = 0; i < n; ++i) {
            action = reduced_plan.at(i);
            cout << "\tstep=" << i << ": ." << reduced_plan.at(i)->getName() << ": {";
            preconditions_formula = action->getPrecondition();
            if (preconditions_formula != nullptr) {
                const auto &formula_type = preconditions_formula->getFormulaType();
                if (formula_type == "and" || formula_type == "or") {
                    preconditions = preconditions_formula->getInnerFormulas();
                } else if (formula_type == "imply") {
                    // todo: ask what to print!!!
                } else {
                    preconditions.push_back(preconditions_formula);
                }
            }
            if (!preconditions.empty()) {
                auto condition = preconditions.begin();
                auto end = --preconditions.end();
                for (; condition != end; ++condition) {
                    cout << **condition << ',';
                }
                cout << **condition;
                preconditions.clear();
            }
            cout << '}' << endl;
        }

        for (const auto &step: running_plan) {
            problem->enter_state();
            if (step.find("assume-") == 0 || step.find("invariant-at-least-one-") == 0)
                continue;
            if (problem->act(step)) {
                if (step.find("sensor-") == 0)
                    continue;
                cout << ">>> kp-action=" << step << " [action=" << step << "]" << endl;
                cout << ">>>> state=";
                print_state(problem);
                plan.push_back(step);
            } else {
                break;
            }
        }
    }
    auto need_indent = false;
    cout << "PLAN:";
    auto plan_n = plan.size();
    for (i = 0; i < plan_n; ++i) {
        if (need_indent) {
            cout << "    ";
            if (i < 10)
                cout << ' ';
        }
        cout << "     " << i << " : " << plan.at(i) << endl;
        need_indent = true;
    }
    std::cout << "Replanning took " << float(clock() - begin_time) / CLOCKS_PER_SEC << " seconds." << std::endl;
}

void print_state(const CompiledProblem *problem) {
    const deque<std::string> &state = problem->get_state();
    if (state.empty()) {
        cout << "{}" << endl;
    } else {
        size_t n = state.size() - 1;
        int i;
        cout << '{';
        for (i = 0; i < n; ++i) {
            cout << '(' << state.at(i) << "),";
        }
        cout << '(' << state.at(i) << ")}" << endl;
    }
}
