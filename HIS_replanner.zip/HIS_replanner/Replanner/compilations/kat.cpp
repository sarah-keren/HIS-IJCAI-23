
#include "kat.h"
#include "kp.h"

CompiledProblem *kat_compile(const Problem &problem) {
    const std::string objective;
    return kat_compile(problem, objective);
}

CompiledProblem *kat_compile(const Problem &problem, const std::string &objective) {

    CompiledProblem *compiled_problem;
    deque<Action *> actions, tmp_actions;
    deque<pair<Formula *, string>> sensors_model, invariants_model;
    Formula *effect;
    Action *action;
    bool state;
    FunctionFormula *functionFormula;

    std::deque<Action *> exe_actions, as_actions, ram_actions, ka_actions;

    auto predicates_map = compile_predicates_map(problem.getPredicatesMap());
    map<string, bool> facts_evaluation = calculate_fact_evaluation(problem, predicates_map);

    auto fo_facts_evaluation = map<string, bool>(facts_evaluation);
    for (const auto &fact: problem.getHidden()) {
        state = fact->getState();
        fo_facts_evaluation.at(fact_to_predicate_name(fact, state)) = true;
    }

    auto *goal_action = create_goal_action(problem, predicates_map);
    actions.push_back(goal_action);
    deque<string> goal = {goal_action->getEffect()->getFormulaType()};
    goal.shrink_to_fit();

    auto old_actions = problem.getActions();
    for (auto action_it = old_actions.begin(); action_it != old_actions.end();) {
        action = *action_it;
        tmp_actions = compile_action(action, predicates_map, facts_evaluation);
        if (tmp_actions.empty()) {
            effect = action->getEffect();
            for (const auto &predicate: effect->getRelatedPredicates()) {
                predicate->setIsChangeable(false);
            }
            action_it = old_actions.erase(action_it);
            for (auto &running_action: old_actions) {
                effect = running_action->getEffect();
                for (const auto &predicate: effect->getRelatedPredicates()) {
                    predicate->setIsChangeable(true);
                }
            }
        } else {
            ++action_it;
            const string &action_name = action->getName();
            if (action_name.find("information-shaping-") == 0) {
                ka_actions.insert(ka_actions.end(), tmp_actions.begin(), tmp_actions.end());
            } else if ((action_name.find("sensor-") == 0) || (action_name.find("assume-") == 0)) {
                as_actions.insert(as_actions.end(), tmp_actions.begin(), tmp_actions.end());
            } else {
                exe_actions.insert(exe_actions.end(), tmp_actions.begin(), tmp_actions.end());
            }
        }
    }
    exe_actions.shrink_to_fit();
    ka_actions.shrink_to_fit();
    as_actions.shrink_to_fit();

    for (auto invariant: problem.getInvariants()) {
        auto tmp = compile_invariant(invariant, predicates_map);
        invariants_model.insert(invariants_model.end(), tmp.second.begin(), tmp.second.end());
        ram_actions.insert(ram_actions.end(), tmp.first.begin(), tmp.first.end());
    }
    ram_actions.shrink_to_fit();

    auto cost_function = new Function("total-cost", deque<PDDL_Object *>(), 0);
    cost_function->setFunctionMetric("minimize");
    deque<Function *> functions = {cost_function};
    functions.shrink_to_fit();
    size_t ka_cost = 1, exe_cost = 1, as_cost = 1, ram_cost = 0;

    if (objective == "min-ka") {
        // exe_cost = 10;
        ka_cost = exe_cost * exe_actions.size() + as_actions.size() + ram_actions.size() + 1;
    } else if (objective == "min-ka-exe") {
        exe_cost = as_actions.size() + ram_actions.size() + 1;
        ka_cost = as_actions.size() + ram_actions.size() + (exe_cost * exe_actions.size()) + 1;
    } else if (objective == "min-exe-ka") {
        ka_cost = as_actions.size() + ram_actions.size() + 1;
        exe_cost = as_actions.size() + ram_actions.size() + (ka_cost * ka_actions.size()) + 1;
    } else if (objective == "min-ram-ka") {
        ka_cost = as_actions.size() + exe_actions.size() + 1;
        ram_cost = as_actions.size() + exe_actions.size() + (ka_cost * ka_actions.size()) + 1;
    } else if (objective == "min-as-ka") {
        ka_cost = exe_actions.size() + ram_actions.size() + 1;
        as_cost = exe_actions.size() + ram_actions.size() + (ka_cost * ka_actions.size()) + 1;
    }

    FunctionFormula cost_formula(cost_function, deque<Parameter *>(), ka_cost);

    for (auto &ka_action: ka_actions) {
        ka_action->getEffect()->add_inner_function_formula(new FunctionFormula(cost_formula));
        actions.push_back(ka_action);
    }
    cost_formula = FunctionFormula(cost_function, deque<Parameter *>(), exe_cost);
    for (auto &exe_action: exe_actions) {
        exe_action->getEffect()->add_inner_function_formula(new FunctionFormula(cost_formula));
        actions.push_back(exe_action);
    }
    cost_formula = FunctionFormula(cost_function, deque<Parameter *>(), as_cost);
    for (auto &as_action: as_actions) {
        as_action->getEffect()->add_inner_function_formula(new FunctionFormula(cost_formula));
        actions.push_back(as_action);
    }
    cost_formula = FunctionFormula(cost_function, deque<Parameter *>(), ram_cost);
    for (auto &ram_action: ram_actions) {
        ram_action->getEffect()->add_inner_function_formula(new FunctionFormula(cost_formula));
        actions.push_back(ram_action);
    }
    actions.shrink_to_fit();

    const string &problemName = problem.getProblemName();
    const string &domainName = problem.getDomainName();
    const deque<string> &requirements = problem.getRequirements();

    compiled_problem = new CompiledProblem(problemName, domainName, requirements, predicates_map, sensors_model,
                                           invariants_model, facts_evaluation, goal, actions, functions);

    return compiled_problem;
}


