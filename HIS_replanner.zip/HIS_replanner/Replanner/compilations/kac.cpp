
#include "kac.h"

CompiledProblem *kac_compile(const Problem &problem) {

    CompiledProblem *compiled_problem;
    deque<Action *> actions, tmp_actions;
    deque<pair<Formula *, string>> sensors_model, invariants_model;
    Formula *effect;
    Action *action;
    bool state;
    FunctionFormula *functionFormula;

    auto cost_function = new Function("total-cost", deque<PDDL_Object *>(), 0);
    cost_function->setFunctionMetric("minimize");
    deque<Function *> functions = {cost_function};
    FunctionFormula kac_cost_formula(cost_function, deque<Parameter *>(), 1);
    FunctionFormula exe_cost_formula(cost_function, deque<Parameter *>(), 1000);
    FunctionFormula assume_cost_formula(cost_function, deque<Parameter *>(), 1);
    FunctionFormula invariant_cost_formula(cost_function, deque<Parameter *>(), 0);

    auto predicates_map = compile_predicates_map(problem.getPredicatesMap());
    map<string, bool> facts_evaluation = calculate_fact_evaluation(problem, predicates_map);

    auto fo_facts_evaluation = map<string, bool>(facts_evaluation);
    for (const auto &fact: problem.getHidden()) {
        state = fact->getState();
        fo_facts_evaluation.at(fact_to_predicate_name(fact, state)) = true;
    }

    auto *goal_action = create_goal_action(problem, predicates_map);
    actions.push_back(goal_action);
    deque<string> goal = {goal_action->getEffect()->getFormulaType()};

    auto old_actions = problem.getActions();
    for (auto action_it = old_actions.begin(); action_it != old_actions.end();) {
        action = *action_it;
        functionFormula = action->getName().find("act_kac_") == 0 ? &kac_cost_formula : &exe_cost_formula;
        tmp_actions = compile_action(action, predicates_map, facts_evaluation);
        if (tmp_actions.empty()) {
            effect = action->getEffect();
            for (const auto &predicate: effect->getRelatedPredicates()) {
                predicate->setIsChangeable(false);
            }
            action_it = old_actions.erase(action_it);
            for (auto &running_action: old_actions) {
                effect = running_action->getEffect();
                for (const auto &predicate: effect->getRelatedPredicates()) {
                    predicate->setIsChangeable(true);
                }
            }
        } else {
            ++action_it;
        }
        for (auto &tmp_action: tmp_actions) {
            tmp_action->getEffect()->add_inner_function_formula(new FunctionFormula(*functionFormula));
            actions.push_back(tmp_action);
        }
    }

    for (auto invariant: problem.getInvariants()) {
        auto tmp = compile_invariant(invariant, predicates_map);
        invariants_model.insert(invariants_model.end(), tmp.second.begin(), tmp.second.end());
        for (const auto &tmp_action: tmp.first) {
            tmp_action->getEffect()->add_inner_function_formula(new FunctionFormula(invariant_cost_formula));
            actions.push_back(tmp_action);
        }
    }

    const string &problemName = problem.getProblemName();
    const string &domainName = problem.getDomainName();
    const deque<string> &requirements = problem.getRequirements();

    compiled_problem = new CompiledProblem(problemName, domainName, requirements, predicates_map, sensors_model,
                                           invariants_model, facts_evaluation, goal, actions, functions);

    return compiled_problem;
}
