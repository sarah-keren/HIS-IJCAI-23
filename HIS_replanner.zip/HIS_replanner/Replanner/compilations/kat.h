

#ifndef REPLANNER_KAT_H
#define REPLANNER_KAT_H

#include "../CompiledProblem.h"
#include "../problem/Problem.h"

CompiledProblem *kat_compile(const Problem &problem);

CompiledProblem *kat_compile(const Problem &problem, const std::string &objective);

#endif //REPLANNER_KAT_H
