
#ifndef REPLANNER_KAC_H
#define REPLANNER_KAC_H

#include "../CompiledProblem.h"
#include "../problem/Problem.h"
#include "kp.h"

CompiledProblem *kac_compile(const Problem &problem);

#endif //REPLANNER_KAC_H
