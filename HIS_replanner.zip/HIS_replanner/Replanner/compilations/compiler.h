
#ifndef REPLANNER_COMPILER_H
#define REPLANNER_COMPILER_H

#include "kp.h"
#include "kat.h"
#include "kac.h"
#include "kminrob.h"

#include "../CompiledProblem.h"
#include "../problem/Problem.h"
#include "../utils.h"

CompiledProblem *compiler(const Problem &problem, string compilation, map<string, string> &options) {
    cout << "Compiling problem, using ";
    const clock_t begin_time = clock();
    CompiledProblem *compiled_problem;
    boost::to_lower(compilation);

//    int precision = stoi(options.at("precision"));
    string &objective = options.at("objective");
    float robustness = stof(options.at("robustness"));

    if (compilation == "kac") {
        cout << "kac compilation" << endl;
        compiled_problem = kac_compile(problem);
    } else if (compilation == "kat") {
        cout << "kat compilation" << endl;
        compiled_problem = kat_compile(problem, objective);
    } else if(compilation == "kminrob") {
        cout << "kminrob compilation" << endl;
        compiled_problem = kminrob_compile(problem, objective, robustness);
    }
    else {
        cout << "kp compilation" << endl;
        compiled_problem = kp_compile(problem);
    }
    std::cout << "Compiling problem took " << float(clock() - begin_time) / CLOCKS_PER_SEC << " seconds." << std::endl;
    return compiled_problem;
}

#endif //REPLANNER_COMPILER_H
