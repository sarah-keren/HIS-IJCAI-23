
#ifndef REPLANNER_KMINROB_H
#define REPLANNER_KMINROB_H

#include "../CompiledProblem.h"
#include "../problem/Problem.h"

CompiledProblem *kminrob_compile(const Problem &problem, const std::string &objective, const float &robustness);

#endif //REPLANNER_KMINROB_H
