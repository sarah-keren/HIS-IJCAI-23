
#ifndef REPLANNER_COMPILEDPROBLEM_H
#define REPLANNER_COMPILEDPROBLEM_H

#include "problem/Action.h"
#include "problem/Predicate.h"
#include "problem/Function.h"
#include "problem/budget.h"

enum FormulaType {
    always_true, always_false, changeable
};


class CompiledProblem {
private:
    const std::string problem_name, domain_name;
    std::deque<std::string> requirements;
    std::map<std::string, Predicate *> predicates_map;
    std::deque<std::pair<Formula *, std::string>> sensors_model, invariants_model;
    std::map<std::string, bool> facts_evaluations;
    std::map<std::string, Action *> actions_map;
    std::deque<std::string> goal;
    std::map<std::string, Function *> functions_map;
    std::map<string, Budget*> budget_map;

    void sense();

    bool is_formula_hold(Formula *formula);

    void domain_to_pddl(const std::string &destination, const std::string &domainName);

    void problem_to_pddl(const std::string &destination, const std::string &problemName);

    void remove_unnecessary_inner_formulas(Formula *formula);

    FormulaType process_formula(Formula *formula);

    void apply_effect(Formula *effect);

public:
    CompiledProblem(std::string problemName, std::string domainName,
                    std::deque<std::string> requirements,
                    std::map<std::string, Predicate *> predicatesMap,
                    std::deque<std::pair<Formula *, std::string>> sensorsModel,
                    std::deque<std::pair<Formula *, std::string>> invariants_model,
                    std::map<std::string, bool> factsEvaluations, std::deque<std::string> goal,
                    const std::deque<Action *> &actions, const std::deque<Function *> &functions);

    CompiledProblem(std::string problemName, std::string domainName,
                    std::deque<std::string> requirements,
                    std::map<std::string, Predicate *> predicatesMap,
                    std::deque<std::pair<Formula *, std::string>> sensorsModel,
                    std::deque<std::pair<Formula *, std::string>> invariants_model,
                    std::map<std::string, bool> factsEvaluations, std::deque<std::string> goal,
                    const std::deque<Action *> &actions, const std::deque<Function *> &functions, const std::deque<Budget *> &budgets);

    virtual ~CompiledProblem();

    void enter_state();

    bool act(const std::string &action_name);

    void deduce();

    bool is_goal_reached() const;

    std::deque<std::string> get_state() const;

    void optimize();

    void to_pddl(const std::string &destination, const std::string &problemName, const std::string &domainName);

    const Action *get_action(const std::string &action_name) const;

};


#endif //REPLANNER_COMPILEDPROBLEM_H
